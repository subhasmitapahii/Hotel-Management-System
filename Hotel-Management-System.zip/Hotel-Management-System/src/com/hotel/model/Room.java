package com.hotel.model;

public class Room {
    private int roomId;
    private String roomNumber;
    private String roomType;
    private double price;
    private String status;

    // getters and setters
}

