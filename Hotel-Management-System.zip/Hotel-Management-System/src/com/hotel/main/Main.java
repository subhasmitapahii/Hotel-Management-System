package com.hotel.main;

import com.hotel.ui.LoginFrame;

public class Main {
    public static void main(String[] args) {
        new LoginFrame();
    }
}
